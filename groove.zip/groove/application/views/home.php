<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
 <?php $name = $this->session->userdata('email'); ?>


<?php
        $query = $this->db->query("select * from users where email = '$name'");

        foreach ($query->result() as $row) { ?>
<?php }?>
Welcome <?php echo $row->username; ?>
 <?php foreach ($data as $datas) { ?>
<br>
<fieldset>
<?php echo $datas->username; ?>:  <?php echo $datas->message; ?>
<br><div style="color:red">
<?php echo $datas->sent_at; ?>
</div>
</fieldset>
<?php }?>
<br>

<form action="#" method="post">
<input type="hidden" name="user" value='<?php echo $row->username; ?>'><br>
<input type="text" name="message" placeholder="Type your message" required>
<br>
<button name="send">Send</button>
</form>
</body>
</html>
