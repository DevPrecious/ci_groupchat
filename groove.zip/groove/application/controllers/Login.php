
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {


public function __construct()
	{
		parent::__construct();
		$this->load->database();

		/*load Model*/
		$this->load->model('msg');
	}
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 public function index()
    {
        $this->form_validation->set_rules('email', 'Email', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');

        if ($this->form_validation->run() == TRUE) {

            $email = $_POST['email'];
            $password = md5($_POST['password']);

            $this->db->select('*');
            $this->db->from('users');
            $this->db->where(array('email' => $email, 'password' => $password));
            $query = $this->db->get();

            $user = $query->row();
            if ($user) {
                $this->session->set_flashdata('success_login', 'You are logged in');

                $_SESSION['user_logged'] = TRUE;
                $_SESSION['email'] = $user->email;

                redirect('login/home', 'refresh');
            } else {
                $this->session->set_flashdata('error_login', 'Invalid email or password');
                redirect('login', 'refresh');
            }
        }

        $this->load->view('login');
    }


    public function home()
    {

    	if(isset($_POST['send']))
    	{
    		$data = array(
    			'username' => $_POST['user'],
    			'message' => $_POST['message'],
    			'sent_at' => date('Y-m-h')
    		);

    		$this->db->insert('msg', $data);
    		redirect(current_url(), 'refresh');
    	}

    	$result['data'] = $this->msg->allmsg();

    	$this->load->view('home', $result);
    }
}
