<?php
class msg extends CI_Model
{
    /*View*/
    function allmsg()
    {
        $query = $this->db->query("select * from msg order by user_id DESC");
        return $query->result();
    }

}
